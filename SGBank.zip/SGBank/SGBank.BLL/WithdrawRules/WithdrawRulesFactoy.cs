﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGBank.Models.Interfaces;
using SGBank.Models;

namespace SGBank.BLL.WithdrawRules
{
    public class WithdrawRulesFactoy
    {
        public static IWithdraw Create(AccountType accountType)
        {
            switch (accountType)
            {
                case AccountType.Free:
                    FreeAccountWithdrawRule freeAccount = new FreeAccountWithdrawRule();
                    return freeAccount;
                case AccountType.Basic:
                    BasicAccountWithdrawRule basicAccount = new BasicAccountWithdrawRule();
                    return basicAccount;
                case AccountType.Premium:
                    PremiumAccountWithdrawRule premiumAccount = new PremiumAccountWithdrawRule();
                    return premiumAccount;
                default:
                    throw new Exception("Account type is not supported!");
            }
        }
    }
}
