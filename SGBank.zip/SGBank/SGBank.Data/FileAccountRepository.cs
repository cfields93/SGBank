﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SGBank.Models;
using SGBank.Models.Interfaces;
using System.IO;

namespace SGBank.Data
{
    public class FileAccountRepository : IAccountRepository
    {
        private string _filePath = @"C:\Data\SGBank\Accounts.txt";
        public Account LoadAccount(string AccountNumber)
        {
            List<Account> accounts = new List<Account>();
            using (StreamReader sr = new StreamReader(_filePath))
            {
                sr.ReadLine();
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    Account newAccount = new Account();
                    string[] columns = line.Split(',');

                    newAccount.AccountNumber = columns[0];
                    newAccount.Name = columns[1];
                    newAccount.Balance = decimal.Parse(columns[2]);
                    switch(columns[3])
                    {
                        case "F":
                            newAccount.Type = AccountType.Free;
                            break;
                        case "B":
                            newAccount.Type = AccountType.Basic;
                            break;
                        case "P":
                            newAccount.Type = AccountType.Premium;
                            break;
                        default:
                            break;
                    }
                    

                    accounts.Add(newAccount);
                }
            }
            foreach (var account in accounts)
            {
                if (AccountNumber == account.AccountNumber)
                {
                    return account;
                }
            }
            return null;
        }

        public void SaveAccount(Account account)
        {
            List<Account> accounts = new List<Account>();
            using (StreamReader sr = new StreamReader(_filePath))
            {
                sr.ReadLine();
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    Account newAccount = new Account();
                    string[] columns = line.Split(',');

                    newAccount.AccountNumber = columns[0];
                    newAccount.Name = columns[1];
                    newAccount.Balance = decimal.Parse(columns[2]);
                    switch (columns[3])
                    {
                        case "F":
                            newAccount.Type = AccountType.Free;
                            break;
                        case "B":
                            newAccount.Type = AccountType.Basic;
                            break;
                        case "P":
                            newAccount.Type = AccountType.Premium;
                            break;
                        default:
                            break;
                    }


                    accounts.Add(newAccount);
                }
            }
            foreach (var item in accounts)
            {
                if (account.AccountNumber == item.AccountNumber)
                {
                    item.Balance = account.Balance;
                }
            }
            if (File.Exists(_filePath))
            {
                File.Delete(_filePath);
            }
            using (StreamWriter sw = new StreamWriter(_filePath))
            {
                sw.WriteLine("AccountNumber,Name,Balance,Type");
                foreach (var item in accounts)
                {
                    switch(item.Type)
                    {
                        case AccountType.Basic:
                            sw.WriteLine($"{item.AccountNumber},{item.Name},{item.Balance},B");
                            break;
                        case AccountType.Free:
                            sw.WriteLine($"{item.AccountNumber},{item.Name},{item.Balance},F");
                            break;
                        case AccountType.Premium:
                            sw.WriteLine($"{item.AccountNumber},{item.Name},{item.Balance},P");
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }
}
